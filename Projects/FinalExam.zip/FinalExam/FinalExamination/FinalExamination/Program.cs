﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace FinalExamination
{
    internal class Program
    {
        [STAThread] // Required for Windows Forms applications
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Console and GUI");

            List<CongDan> mangCongDan = null;
            MySqlConnection connection = null;

            try
            {
                connection = CongDan.MoKetNoi(CongDan.connectionString);

                if (connection == null)
                {
                    Console.WriteLine("Không kết nối được CSDL với xâu kết nối " + CongDan.connectionString);
                }
                else
                {
                    mangCongDan = CongDan.DocListCongDan(connection);

                    foreach (CongDan congDan in mangCongDan)
                    {
                        if (congDan.NgaySinh == "01/01/2000")
                        {
                            Console.WriteLine($"MaCD: {congDan.MaCD}, TenCD: {congDan.TenCD}, CCCD: {congDan.CCCD}, GioiTinh: {congDan.GioiTinh}, NgaySinh: {congDan.NgaySinh}, SoDienThoai: {congDan.SoDienThoai}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            connection = CongDan.MoKetNoi(CongDan.connectionString);
            DataTable table = CongDan.DocBangCongDan(connection);
            Console.WriteLine("Nhấn Enter để tiếp tục...");
            Console.ReadLine();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            SearchingCD frm = new SearchingCD();
            frm.table_sim = table;
            Application.Run(frm);
        }
    }
}
    