﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace FinalExamination
{
    public class CongDan
    {
        public string MaCD { get; set; }
        public string TenCD { get; set; }
        public string CCCD { get; set; }
        public string GioiTinh { get; set; }
        public string NgaySinh { get; set; }
        public string SoDienThoai { get; set; }

        public static string connectionString = "Server=localhost;Database=dieutrads;UID=root;Password=Kidhai2k4!!;";

        public static MySqlConnection MoKetNoi(string connectionString)
        {
            MySqlConnection connection = new MySqlConnection(connectionString);
            try
            {
                connection.Open();
                return connection;
            }
            catch
            {
                return null;
            }
        }

        public static List<CongDan> DocListCongDan(MySqlConnection connection)
        {
            List<CongDan> listCongDan = new List<CongDan>();
            MySqlCommand command = new MySqlCommand("SELECT * FROM congdan", connection);
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                CongDan ob1 = new CongDan();
                ob1.MaCD = reader["MaCD"].ToString();
                ob1.TenCD = reader["TenCD"].ToString();
                ob1.CCCD = reader["CCCD"].ToString();
                ob1.GioiTinh = reader["GioiTinh"].ToString();
                ob1.NgaySinh = reader["NgaySinh"].ToString();

                if (!reader.IsDBNull(reader.GetOrdinal("SoDienThoai")))
                {
                    ob1.SoDienThoai = reader["SoDienThoai"].ToString();
                }
                else
                {
                    ob1.SoDienThoai = null;
                }
                listCongDan.Add(ob1);
            }

            reader.Close();
            command.Dispose();
            return listCongDan;
        }

        public static DataTable DocBangCongDan(MySqlConnection connection)
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM congdan", connection);
            MySqlDataReader reader = command.ExecuteReader();
            DataTable table_out = new DataTable();
            table_out.Columns.Add("MaCD");
            table_out.Columns.Add("TenCD");
            table_out.Columns.Add("CCCD");
            table_out.Columns.Add("GioiTinh");
            table_out.Columns.Add("NgaySinh");
            table_out.Columns.Add("SoDienThoai");

            while (reader.Read())
            {
                DataRow row = table_out.NewRow();
                row["MaCD"] = reader["MaCD"];
                row["TenCD"] = reader["TenCD"];
                row["CCCD"] = reader["CCCD"];
                row["GioiTinh"] = reader["GioiTinh"];
                row["NgaySinh"] = reader["NgaySinh"];
                row["SoDienThoai"] = reader["SoDienThoai"];

                table_out.Rows.Add(row);
            }

            reader.Close();
            command.Dispose();
            return table_out;
        }
    }
}
